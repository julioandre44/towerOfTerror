//********************************************************************************
// PANTHERID:  [6030876 6040474]
// CLASS: COP 2210 – [fall 2017]
// ASSIGNMENT # [4]
// DATE: [11/18/2017]
//
//PATHERID OF ORIGINAL CODER: [6040474]
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else.
//********************************************************************************
package houseofm;
/**
 *
 * @author bryanc
 */
public class HouseOfM {
    //FIXME: Import variables/excess code into a separate method in MRoomDescriptions or another class.
    static MInitialize mi = new MInitialize();

    public static void main(String[] args) {
        //initialization of program
        mi.Introduction();
    }
    
}
